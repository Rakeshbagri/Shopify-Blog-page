$(function ($) {

    /*---------------- Responsive Menu ------------------*/
    $(".nav-trigger").on('click', function (e) {
        $("body").toggleClass('off-canvas-body');
        $(".menu-bar").toggleClass("off-canvas");
        e.preventDefault();
    });
    if ($(window).width() < 768) {
        $('.primary-navbar .dropdown-toggle > span').on("click", function (e) {
            $(this).parent('.dropdown-toggle').toggleClass('active');
            $(this).parent('.dropdown-toggle').next('.dropdown-menu').toggle();
            e.stopPropagation();
            e.preventDefault();
        });
    }
    
    $(document).click(function (e) {
        $(".dropdown").removeClass('open');
        e.stopPropagation();
    });
    $(".dropdown").click(function (e) {
        e.stopPropagation();
    });


    /*---------------- Main Slider ------------------*/
    $('.main-slider').slick({
        autoplay: false,
        arrows: false,
        dots: true
    });


    /*---------------- Filter Toggle ------------------*/
    if ($(window).width() < 767) {
        $('.sidebar-content .title').click(function () {
            $(this).toggleClass('open');
            $(this).parent().find('.inner-content').toggle();
        });
    }

});

jQuery(document).ready(function ($) {

  // This button will increment the value
  $('.btn.plus').click(function (e) {

    // Stop acting like a button
    e.preventDefault();
    // Get the field name
    fieldName = $(this).attr('field');
    // Get its current value
    var currentVal = parseInt($('input[name=' + fieldName + ']').val());
    // If is not undefined
    if (!isNaN(currentVal)) {
      // Increment
      $('input[name=' + fieldName + ']').val(currentVal + 1);
    } else {
      // Otherwise put a 0 there
      $('input[name=' + fieldName + ']').val(1);
    }
  });
  // This button will decrement the value till 0
  $(".btn.minus").click(function (e) {

    // Stop acting like a button
    e.preventDefault();
    // Get the field name
    fieldName = $(this).attr('field');
    // Get its current value
    var currentVal = parseInt($('input[name=' + fieldName + ']').val());
    // If it isn't undefined or its greater than 0
    if (!isNaN(currentVal) && currentVal > 1) {
      // Decrement one
      $('input[name=' + fieldName + ']').val(currentVal - 1);
    } else {
      // Otherwise put a 0 there
      $('input[name=' + fieldName + ']').val(1);
    }
  });
});